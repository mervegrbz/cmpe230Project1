#include <string>
using namespace std;

string evaluateExpression(string exp);
